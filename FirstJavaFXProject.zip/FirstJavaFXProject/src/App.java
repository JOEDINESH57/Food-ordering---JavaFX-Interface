import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.InnerShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;

public class App extends Application {
    Stage stage;
   
    @Override
    public void start(Stage primarystage) throws IOException {
        stage = primarystage;
        Scene scene = LoginScene();
        stage.setTitle("Hospital Management System");
        stage.setMaximized(true);
        stage.setScene(scene);
        stage.show();
        System.out.printf(stage.widthProperty()+" "+stage.heightProperty());

    }
    Scene LoginScene(){
        BorderPane bp = new BorderPane();
        GridPane gp = new GridPane();
        InnerShadow is = new InnerShadow();
        is.setOffsetX(4.0f);
        is.setOffsetY(4.0f);

        Label lna = new Label("Username:");
        //lna.setEffect(is);
        lna.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lna.setTextFill(Color.WHITE);

        Label lpass = new Label("Password:");
       // lpass.setEffect(is);
        lpass.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lpass.setTextFill(Color.WHITE);
        

         
        Text l1 = new Text();
       Pos center = Pos.CENTER;
        l1.setEffect(is);
        l1.setText("LOGIN");
        l1.setFill(Color.WHITESMOKE);
        l1.setFont(Font.font(null, FontWeight.BOLD, 50));


        Button b1 = new Button("Login");
       // b1.setAlignment(Pos.CENTER);
       b1.setEffect(is);
        b1.setMinSize(100,30);
        b1.setTextFill(Color.WHITE);
        b1.setStyle("-fx-background-color: #808080");

        Button b2 = new Button("Sign up");
        //b2.setAlignment(Pos.CENTER);
        b2.setEffect(is);
        b2.setMinSize(100,30);
        b2.setTextFill(Color.WHITE);
        b2.setStyle("-fx-background-color: #808080");


        //b3 exit button
        Button b3 =new Button("Exit");
        b3.setAlignment(Pos.BOTTOM_CENTER);
        b3.setEffect(is);
        b3.setMinSize(100,30);
        b3.setTextFill(Color.WHITE);
        b3.setStyle("-fx-background-color: #808080");
        
        b3.setOnAction(e -> System.exit(0));
        

        //textfields
        TextField tna = new TextField();
        tna.setFont(Font.font("verdana", FontPosture.REGULAR, 20));
        tna.setPromptText("username");

        PasswordField pf = new PasswordField();
        pf.setPromptText("Password");
        pf.setFont(Font.font("verdana", FontPosture.REGULAR, 20));

        
        PasswordField cb = new PasswordField();
        cb.setPromptText("Password");
        cb.setFont(Font.font("verdana", FontPosture.REGULAR, 20));

        VBox vb = new VBox();
        vb.getChildren().addAll(gp,b1,b2,b3);
        vb.setAlignment(Pos.CENTER);
        vb.setSpacing(10);
      
        gp.setHgap(10);
        gp.setVgap(20);
        gp.addRow(1,l1);
        gp.addRow(1);
        gp.addRow(3,lna,tna);
        gp.addRow(4,lpass, pf);
        
    
        gp.setAlignment(Pos.TOP_CENTER);
        
        bp.setCenter(vb);
        bp.setAlignment(vb, Pos.TOP_CENTER);
        Image image = null;
        try {
            FileInputStream file = new FileInputStream("C:/Java/p34-35.jpg");
            image = new Image(file);
        }catch (Exception e){
           
        }
        Background background = new Background(new BackgroundImage(image,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true), new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)));
        bp.setBackground(background);


        b1.setOnMouseClicked(e->switchScenes(homeScene()));
        b2.setOnMouseClicked(e->switchScenes(registerScene()));
        Scene scene = new Scene(bp, 960, 540);
        
        return scene;
       
      
    }

    Scene registerScene(){
        BorderPane bp = new BorderPane();
        GridPane gp = new GridPane();
        InnerShadow is = new InnerShadow();
        is.setOffsetX(4.0f);
        is.setOffsetY(4.0f);


        Label lna = new Label("Username:");
        lna.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lna.setTextFill(Color.WHITE);

        Label lpass = new Label("Age:");
        lpass.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lpass.setTextFill(Color.WHITE);

        Label lemail = new Label("Email:");
        lemail.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lemail.setTextFill(Color.WHITE);

        Label lgen = new Label("Gender");
        lgen.setFont(Font.font("italic", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lgen.setTextFill(Color.WHITE);

        RadioButton r1 = new RadioButton("Male");
        r1.setFont(Font.font("verdana", FontWeight.LIGHT, FontPosture.REGULAR, 20));
        r1.setTextFill(Color.WHITE);

        RadioButton r2 = new RadioButton("Female");
        r2.setFont(Font.font("verdana", FontWeight.LIGHT, FontPosture.REGULAR, 20));
        r2.setTextFill(Color.WHITE);

         Label loc = new Label("Destination:");
    
         loc.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
         loc.setTextFill(Color.WHITE);

         String location[]={"S&H", "EEE", "E&I", "IT Park", "AO Block", "Chemkical Block", "Food Technology","Mechanical Block"};

         ComboBox co = new ComboBox(FXCollections.observableArrayList(location));

         TextField tn4=new TextField();
         tn4.setFont(Font.font("verdana", FontPosture.REGULAR, 20));
        
        Label llas = new Label("Contact:");
        llas.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        llas.setTextFill(Color.WHITE);

        Label Lo = new Label("Register");
        Lo.setEffect(is);
        Lo.setTextFill(Color.WHITE);
        Lo.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
       
        Button b1 = new Button("Ok");
        b1.setEffect(is);
        b1.setMinSize(80,20);
        b1.setTextFill(Color.WHITE);
        b1.setStyle("-fx-background-color: #808080");

        Text t1 = new Text("Already Registered - click to");
        t1.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        t1.setFill(Color.BLUE);
        t1.setStyle("-fx-text-fill: white");

        Button b2 = new Button("Back");
       b2.setEffect(is);
        b2.setMinSize(80,20);
        b2.setTextFill(Color.WHITE);
        b2.setStyle("-fx-background-color: #808080");

        //textfields
        TextField tna = new TextField();
        tna.setFont(Font.font("verdana", FontPosture.REGULAR, 20));
        tna.setPromptText("username");
       
       
       
        TextField tn2 = new TextField();
        tn2.setFont(Font.font("verdana", FontPosture.REGULAR, 20));
        tn2.setPromptText("             @gmail.com");

        TextField pf = new PasswordField();
        pf.setFont(Font.font("verdana", FontPosture.REGULAR, 20));

        TextField cb = new PasswordField();
        cb.setFont(Font.font("verdana", FontPosture.REGULAR, 20));

        VBox vb = new VBox();
        vb.getChildren().addAll(Lo, gp,b1,b2);
        vb.setAlignment(Pos.CENTER);
        vb.setSpacing(20);

        gp.setHgap(20);
        gp.setVgap(20);
        gp.addRow(0,lna, tna);
        gp.addRow(1,lemail,tn2);
        gp.addRow(2,lgen,r1,r2);
        gp.addRow(3,loc,tn4);
        gp.addRow(4,lpass,cb );
        gp.addRow(5,llas, pf);
        gp.setAlignment(Pos.CENTER);

        bp.setCenter(vb);
        bp.setAlignment(vb, Pos.TOP_CENTER);
        Image image = null;
        try {
            FileInputStream file = new FileInputStream("C:/Java/p34-35.jpg");
            image = new Image(file);
        }catch (Exception e){

        }
        Background background = new Background(new BackgroundImage(image,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true), new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)));
        bp.setBackground(background); 
        
        b2.setOnMouseClicked(e->switchScenes(homeScene()));
        b1.setOnMouseClicked(e->switchScenes(exitScene()));
        Scene scene = new Scene(bp, 960, 540);
        return scene;
    }
    Scene registerScene1(){
        BorderPane bp = new BorderPane();
        GridPane gp = new GridPane();
        InnerShadow is = new InnerShadow();
        is.setOffsetX(4.0f);
        is.setOffsetY(4.0f);


        Label lna = new Label("Username:");
        lna.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lna.setTextFill(Color.WHITE);

        Label lpass = new Label("Age:");
        lpass.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lpass.setTextFill(Color.WHITE);

        Label lgen = new Label("Gender");
        lgen.setFont(Font.font("italic", FontWeight.BOLD, FontPosture.REGULAR, 20));
        lgen.setTextFill(Color.WHITE);

        RadioButton r1 = new RadioButton("Male");
        r1.setFont(Font.font("verdana", FontWeight.LIGHT, FontPosture.REGULAR, 20));
        r1.setTextFill(Color.WHITE);

        RadioButton r2 = new RadioButton("Female");
        r2.setFont(Font.font("verdana", FontWeight.LIGHT, FontPosture.REGULAR, 20));
        r2.setTextFill(Color.WHITE);

         Label loc = new Label("Address:");
         loc.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
         loc.setTextFill(Color.WHITE);

         Label lpro=new Label("Problem:");
         lpro.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
         lpro.setTextFill(Color.WHITE);

         TextArea ta1 = new TextArea();
         ta1.setFont(Font.font("verdana", FontPosture.REGULAR, 5));



         Label lno=new Label("No.of.Days:");
         lno.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
         lno.setTextFill(Color.WHITE);

         TextField tn5=new TextField();
         tn5.setFont(Font.font("verdana", FontPosture.REGULAR, 20));
        

         TextField tn4=new TextField();
         tn4.setFont(Font.font("verdana", FontPosture.REGULAR, 20));
        
        Label llas = new Label("Contact:");
        llas.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        llas.setTextFill(Color.WHITE);

        Label Lo = new Label("Register");
        Lo.setEffect(is);
        Lo.setTextFill(Color.WHITE);
        Lo.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
       
        Button b1 = new Button("ok");
        b1.setEffect(is);
        b1.setMinSize(80,20);
        b1.setTextFill(Color.WHITE);
        b1.setStyle("-fx-background-color: #808080");

    
        Button b2 = new Button("Back");

       b2.setEffect(is);
        b2.setMinSize(80,20);
        b2.setTextFill(Color.WHITE);
        b2.setStyle("-fx-background-color: #808080");

        //textfields
        TextField tna = new TextField();
        tna.setFont(Font.font("verdana", FontPosture.REGULAR, 20));
        tna.setPromptText("username");
       
       
       
        TextField tn2 = new TextField();
        tn2.setFont(Font.font("verdana", FontPosture.REGULAR, 20));
        tn2.setPromptText("             @gmail.com");

        TextField pf = new PasswordField();
        pf.setFont(Font.font("verdana", FontPosture.REGULAR, 20));

        TextField cb = new PasswordField();
        cb.setFont(Font.font("verdana", FontPosture.REGULAR, 20));

        VBox vb = new VBox();
        vb.getChildren().addAll(Lo, gp,b1,b2);
        vb.setAlignment(Pos.CENTER);
        vb.setSpacing(20);

        gp.setHgap(20);
        gp.setVgap(20);
        gp.addRow(0,lna, tna);
        gp.addRow(1,lgen,r1,r2);
        gp.addRow(2,loc,tn4);
        gp.addRow(3,lpro,ta1);
        gp.addRow(4,lno,tn5);
        gp.addRow(5,lpass,cb );
        gp.addRow(6,llas, pf);
        gp.setAlignment(Pos.CENTER);

        bp.setCenter(vb);
        bp.setAlignment(vb, Pos.TOP_CENTER);
        Image image = null;
        try {
            FileInputStream file = new FileInputStream("C:/Java/p34-35.jpg");
            image = new Image(file);
        }catch (Exception e){

        }
        Background background = new Background(new BackgroundImage(image,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true), new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)));
        bp.setBackground(background); 
        
        b2.setOnMouseClicked(e->switchScenes(homeScene()));
        b1.setOnMouseClicked(e->switchScenes(exitScene()));
        Scene scene = new Scene(bp, 960, 540);
        return scene;
    }
    public void switchScenes1(Scene scene1){
        stage.setMaximized(true);
        stage.setScene(scene1);
    }
     
    Scene homeScene(){
        BorderPane bp = new BorderPane();
        GridPane gp = new GridPane();
        InnerShadow is = new InnerShadow();
        is.setOffsetX(4.0f);
        is.setOffsetY(4.0f);
        

        Button b1 = new Button("Doctor");
        b1.setEffect(is);
        b1.setMinSize(80,20);
        b1.setTextFill(Color.WHITE);
        b1.setStyle("-fx-background-color: #808080");

        Button b2 = new Button("Patient");
        b2.setEffect(is);
        b2.setMinSize(80,20);
        b2.setTextFill(Color.WHITE);
        b2.setStyle("-fx-background-color: #808080");

        Button b3 = new Button("Back");
        b3.setEffect(is);
        b3.setMinSize(80,20);
        b3.setTextFill(Color.WHITE);
        b3.setStyle("-fx-background-color: #808080");


        VBox vb = new VBox();
        vb.getChildren().addAll( gp,b1,b2,b3);
        vb.setAlignment(Pos.CENTER);
        vb.setSpacing(20);

        gp.setHgap(20);
        gp.setVgap(20);
       
        gp.addRow(0,b1);
        gp.addRow(1,b2);
        gp.setAlignment(Pos.TOP_CENTER);

        bp.setCenter(vb);
        bp.setAlignment(vb, Pos.TOP_CENTER);
        Image image = null;
        try {
            FileInputStream file = new FileInputStream("C:/Java/p34-35.jpg");
            image = new Image(file);
        }catch (Exception e){

        }
        Background background = new Background(new BackgroundImage(image,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true), new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)));
        bp.setBackground(background);
        b1.setOnMouseClicked(e->switchScenes(exitScene()));
       
        b1.setOnMouseClicked(e->switchScenes(registerScene()));
        b2.setOnMouseClicked(e->switchScenes(registerScene1()));
        b3.setOnMouseClicked(e->switchScenes(LoginScene()));
        Scene scene = new Scene(bp, 960, 540);
        return scene;
    }
    public void switchScenes(Scene scene){
        stage.setMaximized(true);
        stage.setScene(scene);
    }  
   
    Scene exitScene(){
        BorderPane bp = new BorderPane();
        GridPane gp = new GridPane();
        InnerShadow is = new InnerShadow();
        is.setOffsetX(4.0f);
        is.setOffsetY(4.0f);


        VBox vb = new VBox();
        vb.getChildren().addAll( gp);
        vb.setAlignment(Pos.CENTER);
        vb.setSpacing(20);

        gp.setHgap(20);
        gp.setVgap(20);
        gp.setAlignment(Pos.TOP_CENTER);

        bp.setCenter(vb);
        bp.setAlignment(vb, Pos.TOP_CENTER);
        Image image = null;
        try {
            FileInputStream file = new FileInputStream("C://Java/wallpaperflare.com_wallpaper.jpg");
            image = new Image(file);
        }catch (Exception e){

        }
        Background background = new Background(new BackgroundImage(image,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true), new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)));
        bp.setBackground(background);
        Scene scene = new Scene(bp, 960, 540);
        return scene;
    }


    public static void main(String[] args) {
        launch();
    }
}